export default function CustomerDashboard() {
    return <h1>CustomerDashboard</h1>
}